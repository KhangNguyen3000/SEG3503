package ebook.controller;

import static org.junit.Assert.*;
import org.junit.*;
import ebook.controller.EbookingControl;
import ebook.controller.EbookingEventNotDefinedException;
import ebook.simulator.BasicReactions;

public class EbookingControlTest {
	EbookingControl controler;
	enum Status  {IDLE, LOOKINGUPRESERVATION, DISPLAYINGFLIGHT, WAITFORRESPONSE, 
		WAITFORBAGGAGENUMBERS,WAITFORDOCUMENTSWITHRAWAL, SOUNDINGALARM}
	Status expected;
	
	@Before
	public void build() {
	controler = new EbookingControl(new BasicReactions());
	expected = Status.IDLE;
	assertEquals(expected.toString(),controler.getCurrent().toString());
	}
	
/*	@Test //(expected = EbookingEventNotDefinedException.class )
	public void test() throws EbookingEventNotDefinedException {
		String expected="LOOKINGUPRESERVATION";
		String actual;
		try {
		controler.reservationNumber();
		actual = controler.getCurrent().toString());
		assertEquals(expected, actual)
		}catch(EbookingEventNotDefinedException e){
			e.printStackTrace();
		}
		
	//	fail("Not yet implemented");
	}*/
	
	@Test
	public void test1() throws EbookingEventNotDefinedException {
		//1.2
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//1.3 Error is expected therefor theres a try catch
		try {
		controler.notFound();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		}catch(EbookingEventNotDefinedException e) {
			e.printStackTrace();
		}
	}
	@Test
	public void test2() throws EbookingEventNotDefinedException {
		//2.2
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//2.3
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//2.4
		controler.cancel();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}
	@Test
	public void test3() throws EbookingEventNotDefinedException {
		//3.2
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//3.3
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//3.4
		controler.change();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}
	@Test
	public void test4() throws EbookingEventNotDefinedException {
		//4.2
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//4.3
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//4.4
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//4.5
		controler.cancel();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}
	
	@Test
	public void test5() throws EbookingEventNotDefinedException {
				//5.2
				controler.reservationNumber();
				expected = Status.LOOKINGUPRESERVATION;
				assertEquals(expected.toString(),controler.getCurrent().toString());
				//5.3
				controler.found();
				expected = Status.DISPLAYINGFLIGHT;
				assertEquals(expected.toString(),controler.getCurrent().toString());
				//5.4
				controler.confirm();
				expected = Status.WAITFORRESPONSE;
				assertEquals(expected.toString(),controler.getCurrent().toString());
				//5.5
				controler.yes();
				expected = Status.WAITFORBAGGAGENUMBERS;
				assertEquals(expected.toString(),controler.getCurrent().toString());
				//5.6
				controler.cancel();
				expected= Status.IDLE;
				assertEquals(expected.toString(),controler.getCurrent().toString());
	}
	
	@Test
	public void test6() throws EbookingEventNotDefinedException {
		//6.2
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//6.3
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//6.4
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//6.5
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//6.6
		controler.numberOfPieces();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//6.7
		controler.cancel();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}
	
	@Test
	public void test7() throws EbookingEventNotDefinedException {
		//7.2
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//7.3
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//7.4
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//7.5
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//7.6
		controler.numberOfPieces();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//7.7
		controler.withdrawDocuments();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		
	}
	
	@Test // ID 8
	public void test8() throws EbookingEventNotDefinedException {
		//8.2
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//8.3
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//8.4
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//8.5
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//8.6
		controler.numberOfPieces();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//8.7
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//8.8
		controler.cancel();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		
	}
	@Test //ID Test 9
	public void test9() throws EbookingEventNotDefinedException {
		//9.2
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//9.3
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//9.4
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//9.5
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//9.6
		controler.numberOfPieces();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//9.7
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//9.8
		controler.withdrawDocuments();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}
	
	@Test //ID Test 10
	public void test10() throws EbookingEventNotDefinedException {
		//10.2
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//10.3
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//10.4
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//10.5
		controler.no();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//10.6
		controler.cancel();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}
	
	@Test //ID Test 11
	public void test11() throws EbookingEventNotDefinedException {
		//11.2
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//10.3
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//10.4
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//10.5
		controler.no();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//10.6
		controler.withdrawDocuments();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}
	
	@Test //ID Test 12
	public void test12() throws EbookingEventNotDefinedException {
		//12.2
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//12.3
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//12.4
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//12.5
		controler.no();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//12.6
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//12.7
		controler.cancel();
		expected= Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}
	
	@Test //ID Test 13
	public void test13() throws EbookingEventNotDefinedException {
		//13.2
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//13.3
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//13.4
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//13.5
		controler.no();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//13.6
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//13.7
		controler.withdrawDocuments();
		expected= Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}
	
	
	@Test
	public void Failure() throws Exception {
		fail();
	}
	

}