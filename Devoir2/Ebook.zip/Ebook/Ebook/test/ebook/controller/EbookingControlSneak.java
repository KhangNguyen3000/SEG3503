package ebook.controller;
import static org.junit.Assert.*;
import org.junit.*;
import ebook.controller.EbookingControl;
import ebook.controller.EbookingEventNotDefinedException;
import ebook.controller.EbookingControlTest.Status;
import ebook.simulator.BasicReactions;

public class EbookingControlSneak {
	EbookingControl controler;
	enum Status  {IDLE, LOOKINGUPRESERVATION, DISPLAYINGFLIGHT, WAITFORRESPONSE, 
		WAITFORBAGGAGENUMBERS,WAITFORDOCUMENTSWITHRAWAL, SOUNDINGALARM}
	Status expected;
	
	@Before
	public void build() {
	controler = new EbookingControl(new BasicReactions());
	expected = Status.IDLE;
	assertEquals(expected.toString(),controler.getCurrent().toString());
	}
	
	@Test //ID 1
	public void test1() throws EbookingEventNotDefinedException {
	try {
		controler.cancel();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 2
	public void test2() throws EbookingEventNotDefinedException {
	try {
		controler.confirm();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 3
	public void test3() throws EbookingEventNotDefinedException {
	try {
		controler.change();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 1
	public void test4() throws EbookingEventNotDefinedException {
	try {
		controler.yes();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 5
	public void test5() throws EbookingEventNotDefinedException {
	try {
		controler.no();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 6
	public void test6() throws EbookingEventNotDefinedException {
	try {
		controler.numberOfPieces();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	
	@Test //ID 7
	public void test7() throws EbookingEventNotDefinedException {
	try {
		controler.withdrawDocuments();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 8
	public void test8() throws EbookingEventNotDefinedException {
	try {
		controler.timeout();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //Test 9 Just realized this test is repetitive from #7
	public void test9() throws EbookingEventNotDefinedException {
	try {
		controler.withdrawDocuments();
		expected = Status.IDLE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 10
	public void test10() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
				controler.found();
		expected = Status.DISPLAYINGFLIGHT;;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.reservationNumber();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	
	@Test //ID 11
	public void test11() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
				controler.found();
		expected = Status.DISPLAYINGFLIGHT;;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.no();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	
	@Test //ID 12
	public void test12() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
				controler.found();
		expected = Status.DISPLAYINGFLIGHT;;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.yes();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	
	@Test //ID 13
	public void test13() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
				controler.found();
		expected = Status.DISPLAYINGFLIGHT;;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.numberOfPieces();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	
	@Test //ID 14
	public void test14() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
				controler.found();
		expected = Status.DISPLAYINGFLIGHT;;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.withdrawDocuments();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 15
	public void test15() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
				controler.found();
		expected = Status.DISPLAYINGFLIGHT;;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.timeout();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 16
	public void test16() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//4.3
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//4.4
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.reservationNumber();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 17
	public void test17() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//4.3
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//4.4
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.change();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 18
	public void test18() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//4.3
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//4.4
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.confirm();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 19
	public void test19() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//4.3
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//4.4
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.numberOfPieces();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 20
	public void test20() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//4.3
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//4.4
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.withdrawDocuments();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 21
	public void test21() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//4.3
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		//4.4
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.timeout();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 22
	public void test22() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.reservationNumber();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 23
	public void test23() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.change();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 24
	public void test24() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.confirm();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 25
	public void test25() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.no();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 26
	public void test26() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.yes();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 27
	public void test27() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.withdrawDocuments();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 28
	public void test28() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.timeout();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 29
	public void test29() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.numberOfPieces();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.reservationNumber();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 30
	public void test30() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.numberOfPieces();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.change();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 31
	public void test31() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.numberOfPieces();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.confirm();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 32
	public void test32() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.numberOfPieces();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.no();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 33
	public void test33() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.numberOfPieces();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.yes();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 34
	public void test34() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.numberOfPieces();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.numberOfPieces();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 35
	public void test35() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.numberOfPieces();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.reservationNumber();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 36
	public void test36() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.numberOfPieces();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.change();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 37
	public void test37() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.numberOfPieces();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.confirm();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 38
	public void test38() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.numberOfPieces();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.no();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 39
	public void test39() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.numberOfPieces();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.yes();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	
	@Test //ID 40
	public void test40() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.numberOfPieces();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.numberOfPieces();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	
	@Test //ID 41
	public void test41() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.yes();
		expected = Status.WAITFORBAGGAGENUMBERS;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.numberOfPieces();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.timeout();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 42
	public void test42() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.no();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.reservationNumber();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 43
	public void test43() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.no();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.change();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 44
	public void test44() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.no();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.confirm();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 45
	public void test45() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.no();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.no();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 46
	public void test46() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.no();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.yes();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 47
	public void test47() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.no();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.numberOfPieces();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 48
	public void test48() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.no();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.reservationNumber();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 49
	public void test49() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.no();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.change();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 50
	public void test50() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.no();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.confirm();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 51
	public void test51() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.no();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.no();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 52
	public void test52() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.no();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.yes();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 53
	public void test53() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.no();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.numberOfPieces();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}
	@Test //ID 54
	public void test54() throws EbookingEventNotDefinedException {
		controler.reservationNumber();
		expected = Status.LOOKINGUPRESERVATION;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.found();
		expected = Status.DISPLAYINGFLIGHT;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.confirm();
		expected = Status.WAITFORRESPONSE;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.no();
		expected = Status.WAITFORDOCUMENTSWITHRAWAL;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		controler.timeout();
		expected = Status.SOUNDINGALARM;
		assertEquals(expected.toString(),controler.getCurrent().toString());
		try {
		controler.timeout();
		assertEquals(expected.toString(),controler.getCurrent().toString());
	}catch(EbookingEventNotDefinedException e) {
		e.printStackTrace();
	}
	}

	
}