package calculator;

import javax.swing.JFrame;

public class Calculator {
	 static public void main(String argv[]) {
	      JFrame frame =
		  new CalCFrame("Calculator");
	      frame.setSize(360,200);
	      frame.setVisible(true);
	  }
}