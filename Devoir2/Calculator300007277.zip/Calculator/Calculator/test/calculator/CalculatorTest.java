//Khang Nguyen 300007277

package calculator;

import java.awt.event.ActionEvent;
import java.lang.reflect.Field;

import javax.swing.JButton;

import org.junit.Assert;
import org.junit.Test;

public class CalculatorTest {
	private final int   ADD=1,        // integer constants representing operators
			SUB = 2, 
			MULT = 3, 
			DIVI = 4, 
			POW = 5, 
			SQRT = 6,
			KHANG = 10;
	
	/*
	 * These tests illustrate how to use Java reflection to access private members
	 */
	@Test
	public void test11() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(true);
		JButton but0 = getButton(calf,0); // get button
		ActionEvent ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("1", calf.getResult().getText());
	}
	
	@Test
	public void test12() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,1); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("2", calf.getResult().getText());
	}	

	@Test
	public void test13() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,2); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("3", calf.getResult().getText());
	}

	@Test
	public void test14() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,5); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("4", calf.getResult().getText());
	}

	@Test
	public void test15() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,6); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("5", calf.getResult().getText());
	}

	@Test
	public void test16() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,7); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("6", calf.getResult().getText());
	}

	@Test
	public void test17() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,10); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("7", calf.getResult().getText());
	}

	@Test
	public void test18() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,11); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("8", calf.getResult().getText());
	}
	
	@Test
	public void test19() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,12); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("9", calf.getResult().getText());
	}

	@Test
	public void test110() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,16); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("0", calf.getResult().getText());
	}

	@Test
	public void test111() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,17); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		but1 = getButton(calf,17); // get button
		ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("0.0", calf.getResult().getText());
	}

	@Test
	public void test112() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,17); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("0.0", calf.getResult().getText());
	}

	@Test(expected = IndexOutOfBoundsException.class)
	public void test113() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,20); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
	}

	@Test
	public void test114() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,14); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("", calf.getResult().getText());
	}
	
	@Test
	public void test115() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but0 = getButton(calf,6); // get button
		ActionEvent ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,14); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("2.23606797749979", calf.getResult().getText());
	}

	@Test
	public void test116() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,13); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("", calf.getResult().getText());
	}
	
	@Test
	public void test117() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but0 = getButton(calf,7); // get button
		ActionEvent ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,13); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("6", calf.getResult().getText());
	}
	
	@Test
	public void test118() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but0 = getButton(calf,0); // get button
		ActionEvent ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,15); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("0", calf.getResult().getText());
	}
	
	@Test
	public void test119() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,18); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("", calf.getResult().getText());
	}
	
	@Test
	public void test120() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but0 = getButton(calf,2); // get button
		ActionEvent ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,18); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("3", calf.getResult().getText());
	}
	
	@Test
	public void test121() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,9); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("", calf.getResult().getText());
	}
	
	@Test
	public void test122() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but0 = getButton(calf,5); // get button
		ActionEvent ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,9); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("4", calf.getResult().getText());
	}	
	@Test
	public void test123() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,8); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("", calf.getResult().getText());
	}
	
	@Test
	public void test124() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but0 = getButton(calf,1); // get button
		ActionEvent ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,8); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("2", calf.getResult().getText());
	}	
	@Test
	public void test125() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,4); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("", calf.getResult().getText());
	}
	
	@Test
	public void test126() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but0 = getButton(calf,7); // get button
		ActionEvent ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,4); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("6", calf.getResult().getText());
	}	
	@Test
	public void test127() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but1 = getButton(calf,3); // get button
		ActionEvent ev = new ActionEvent(but1, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("", calf.getResult().getText());
	}
	
	@Test
	public void test128() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but0 = getButton(calf,10); // get button
		ActionEvent ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,3); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("7", calf.getResult().getText());
	}

	@Test
	public void test21() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but0 = getButton(calf,2); // get button
		ActionEvent ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,18); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("3", calf.getResult().getText());
	}
	
	@Test
	public void test22() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but0 = getButton(calf,5); // get button
		ActionEvent ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,14); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("2.0", calf.getResult().getText());
	}
	
	@Test
	public void test23() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but0 = getButton(calf,2); // get button
		ActionEvent ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,3); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,5); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,18); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("7.0", calf.getResult().getText());
	}
	
	@Test
	public void test24() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but0 = getButton(calf,12); // get button
		ActionEvent ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,3); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,2); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,9); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,1); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,9); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("6.0", calf.getResult().getText());
	}
	
	@Test
	public void test25() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		JButton but0 = getButton(calf,7); // get button
		ActionEvent ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,8); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,5); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,4); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		Assert.assertEquals("24.0", calf.getResult().getText());
	}
	
	@Test
	public void test26() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		
		JButton but0 = getButton(calf,10); // get button
		ActionEvent ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);		
		but0 = getButton(calf,3); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,11); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,8); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,12); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		but0 = getButton(calf,18); // get button
		ev = new ActionEvent(but0, 0, null); // generate a click on button
		calf.actionPerformed(ev);
		
		Assert.assertEquals("135.0", calf.getResult().getText());
	}
	
	@Test
	public void test31() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		int number1 = 12;
		int number2 = 32;
		int oper = ADD;
		Assert.assertEquals(44.0,calf.calculate(oper, number1, number2), 0);
	}
	
	@Test
	public void test32() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		int number1 = 45;
		int number2 = 23;
		int oper = SUB;
		Assert.assertEquals(22.0,calf.calculate(oper, number1, number2), 0);
	}

	@Test
	public void test33() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		int number1 = 2;
		int number2 = 54;
		int oper = MULT;
		Assert.assertEquals(108.0,calf.calculate(oper, number1, number2), 0);
	}

	@Test
	public void test34() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		int number1 = 24;
		int number2 = 43;
		int oper = DIVI;
		Assert.assertEquals(0.5581395348837209,calf.calculate(oper, number1, number2), 0);
	}

	@Test
	public void test35() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		int number1 = 654;
		int number2 = 3;
		int oper = POW;
		Assert.assertEquals(2.79726264E8,calf.calculate(oper, number1, number2), 0);
	}

	@Test
	public void test36() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		int number1 = 43;
		int oper = SQRT;
		Assert.assertEquals(6.557438524302,calf.calculate(oper, number1, 0.0), 0);
	}

	@Test
	public void test37() {
		CalCFrame calf = new CalCFrame("Tester");
		calf.setClearscreen(false);
		int number1 = 3;
		int number2 = 3223;
		int oper = KHANG;
		Assert.assertEquals(0.0,calf.calculate(oper, number1, number2), 0);
	}
	
	
	
	// using Java reflection to access the calculator buttons
	private JButton getButton(CalCFrame calf,int b) {
		Field fb;
		JButton but = null;
		try {
			fb = calf.getClass().getDeclaredField("buttons");
			fb.setAccessible(true);
			but = ((JButton[]) fb.get(calf))[b];
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return but;
	}
}