//==============================================================================
//Calculator.java (S. Some)
//This program is largely based on  AwtCalc.java
//Author:  Ernest Criss Jr.
//==============================================================================

package calculator;

import javax.swing.JFrame;

public class Calculator {
	 static public void main(String argv[]) {
	      JFrame frame =
		  new CalCFrame("Calculator");
	      frame.setSize(360,200);
	      frame.setVisible(true);
	  }
}
