package calculator;

import static org.junit.Assert.*;

import java.lang.reflect.Field;

import org.junit.Test;

public class CalCFrameTest {

	private void setClearscreen(CalCFrame cframe, boolean val) {
		try {
			Field f = cframe.getClass().getDeclaredField("clearscreen");
			f.setAccessible(true);
			f.setBoolean(cframe, val);
		} catch (NoSuchFieldException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
