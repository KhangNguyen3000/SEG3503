package selenium;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class SampleSeleniumTests {
	static Process server;
	private WebDriver driver;
	
	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver","E:\\Program Files\\webdrivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://localhost:8080/");
		// wait to make sure Selenium is done loading the page
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("title")));
	}

	@After
	public void tearDown() {
		driver.close();
	}
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
    	ProcessBuilder pb = new ProcessBuilder("java", "-jar", "bookstore5.jar");
    	server = pb.start();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		server.destroy();
	}

	@Test
	public void test1() {
		WebElement element = driver.findElement(By.id("title"));
		String expected = "YAMAZONE BookStore";
		String actual = element.getText();
		Assert.assertEquals(expected, actual);
		
	}
	
	@Test
	public void test2() {
		WebElement welcome = driver.findElement(By.cssSelector("p"));
		String expected = "Welcome";
		String actual = welcome.getText();
		Assert.assertEquals(expected, getWords(actual)[0]);
		WebElement langSelector = driver.findElement(By.id("locales"));
		langSelector.click();
		WebElement frSelector = driver.findElement(By.cssSelector("option:nth-child(3)"));
		frSelector.click();
		welcome = driver.findElement(By.cssSelector("p"));
		expected = "Bienvenu";
		actual = welcome.getText();
		Assert.assertEquals(expected, getWords(actual)[0]);
	}
	
	private String[] getWords(String s) {
		return s.split("\\s+");
	}

}
